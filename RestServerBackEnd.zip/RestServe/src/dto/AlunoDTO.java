/**
* Aplicação com serviços REST para gestão de cursos.
*
* @author  Thiago Silva de Souza
* @version 1.0
* @since   2012-02-29 
*/

package dto;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="aluno")
public class AlunoDTO {
	private int matricula;
	private String nome;
	private String dtNascimento;
	private int curso;
	private String cpf;
	
	

	public AlunoDTO() {

	}

	public AlunoDTO(int matricula, 
			String nome,String cpf, 
			String dtNascimento,			
			int curso) {
		this.matricula = matricula;
		this.nome = nome;
		this.cpf=cpf;
		this.dtNascimento = dtNascimento;
		this.curso = curso;
		
		
	}
	
	private int getIdadeConvertida(String data)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dataConvertida = null;
		try {
			dataConvertida = sdf.parse(data);
			Date hoje = new Date();
			return hoje.getYear() - dataConvertida.getYear();
		} catch (Exception e) {
			System.out.println("Erro Convers�o da idade: " + e.getMessage());
			return 0;
		}
	}
	
	
	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public int getCurso() {
		return curso;
	}

	public void setCurso(int curso) {
		this.curso = curso;
	}

	public String getDtNascimento() {
		return dtNascimento;
	}

	public void setDtNascimento(String dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	
}
