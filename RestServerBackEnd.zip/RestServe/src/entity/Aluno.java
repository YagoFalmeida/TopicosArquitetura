package entity;

public class Aluno {
	private int matricula;
	private String nome;
	private String cpf;
	private entity.Data dataNascimento;
	private Curso curso;
	


	public Aluno(int matricula, String nome, String cpf, entity.Data data, Curso curso) {
		this.matricula = matricula;
		this.nome = nome;
		this.cpf=cpf;
		this.dataNascimento = data;
		
		this.curso = curso;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public Data getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Data dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	

	public Curso getCurso() {
		return curso;
	}
	
	public void setCurso(Curso curso) {
		this.curso = curso;
	}


	
}
