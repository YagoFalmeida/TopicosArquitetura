var botaoBuscar = document.querySelector("#buscar-aluno");

botaoBuscar.addEventListener("click", function() {

    var xhr = new XMLHttpRequest();


    /*
	Este true � opcional, serve apenas para indicar que o objeto XMLHttpRequest est� enviando uma requisi��o ass�ncrona, tendo o 'true' j� como default.
    */
    xhr.open("GET", "http://localhost:8080/RestServe/aluno/", true);
	




    xhr.onreadystatechange = adicionaAlunoNaTabela;


    function adicionaAlunoNaTabela() {
        
 	    if (xhr.readyState == 4) { // 'ReadyState: 4' � a mesma coisa que o evento 'load'
   
    	        var myObj = JSON.parse(xhr.responseText);

//              alert(pessoa.estadocivil); Apenas para teste*

	        var tabela = document.querySelector("#tabela-alunos");
			tabela.innerHTML="";
            
		for(var i = 0; i < myObj.alunos.length; i++) { // 'alunos' � a lista JSON que cont�m os alunos
                    tabela.appendChild(montaTr(myObj.alunos[i]));
		}
   
            }

    }



    
    xhr.send();


// Este trecho de c�digo abaixo foi substitu�do pelos acima
// por�m faz exatamente a mesma coisa.
//
//
//    xhr.addEventListener("load", function() {
//        var resposta = xhr.responseText;
//        var pessoa = JSON.parse(resposta);
//
//	
//
//        alunos.forEach(function(aluno) {
//            adicionaAlunoNaTabela(aluno);
//        });
//
//
//    });

	
    


});                            
               




                 
